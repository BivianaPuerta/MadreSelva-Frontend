package com.madreselva.reto5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reto5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
